import pytest
from hwassist import tools

ARRAY = """Handle 0x0010, DMI type 16, 23 bytes
Physical Memory Array
\tLocation: System Board Or Motherboard
\tUse: System Memory
\tMaximum Capacity: 64 GB
\tNumber Of Devices: 2
"""

DEVICES = """Handle 0x0011, DMI type 17, 40 bytes
Memory Device
\tSize: 16 GB
\tLocator: DIMM A
\tType: DDR4
\tSpeed: 3200 MT/s

Handle 0x0012, DMI type 17, 40 bytes
Memory Device
\tSize: No Module Installed
\tLocator: DIMM B
\tType: Unknown
"""


def test_array():
    assert tools.parse_dmi_array(ARRAY) == [{"max_capacity_mb": 65536, "slots": 2}]


def test_devices():
    s = tools.parse_dmi_devices(DEVICES)
    assert len(s) == 2
    assert s[0]["size_mb"] == 16384 and s[0]["type"] == "DDR4"
    assert s[1]["size_mb"] is None


def test_ram_slots_math(monkeypatch):
    fake = {"dmi_array": ARRAY, "dmi_devices": DEVICES}
    monkeypatch.setattr(tools, "_run", lambda name: fake[name])
    r = tools.get_ram_slots()
    assert (r["slots_total"], r["slots_used"], r["slots_free"]) == (2, 1, 1)
    assert r["max_additional_gb"] == 48.0


def test_missing_root_gives_error_not_crash(monkeypatch):
    def boom(name):
        raise tools.ToolError("needs root")
    monkeypatch.setattr(tools, "_run", boom)
    assert "error" in tools.call_tool("get_ram_slots")


def test_unknown_tool_rejected():
    assert "error" in tools.call_tool("rm -rf /")


def test_storage_kinds(monkeypatch):
    import json
    out = json.dumps({"blockdevices": [
        {"name": "nvme0n1", "size": 512110190592, "type": "disk", "rota": False, "tran": "nvme", "model": "X"},
        {"name": "sda", "size": 1000204886016, "type": "disk", "rota": True, "tran": "sata", "model": "Y"},
        {"name": "sdb", "size": 256060514304, "type": "disk", "rota": "0", "tran": "sata", "model": "Z"},
    ]})
    monkeypatch.setattr(tools, "_run", lambda name: out)
    kinds = [d["kind"] for d in tools.get_storage()["disks"]]
    assert kinds == ["NVMe SSD", "HDD", "SSD (SATA/other)"]
