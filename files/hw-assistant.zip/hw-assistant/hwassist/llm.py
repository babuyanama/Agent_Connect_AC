"""Talks to a local model through Ollama. Nothing leaves the machine."""
import json
import urllib.request

OLLAMA_URL = "http://localhost:11434/api/chat"


def chat(messages, tools, model):
    body = json.dumps({
        "model": model,
        "messages": messages,
        "tools": tools,
        "stream": False,
        "options": {"temperature": 0},   # facts, not creativity
    }).encode()
    req = urllib.request.Request(OLLAMA_URL, body, {"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.loads(r.read())["message"]
